							## UI Automation Suite ## 
							
## Project Name ##
Software Testing Assignment – Complete QA Suite

## Tested Application ##
https://www.saucedemo.com/ 
							
## 2) UI Automation Testing (Selenium + Java)
							
							
### Tools
- Selenium WebDriver
- Java
- TestNG
- Eclipse IDE
- Microsoft EdgeDriver

### Automated Test Classes
- LoginPage (valid login)
- LoginPage2 (invalid login)
- AddToCart
- RemoveFromCart
- CheckoutSuccess
- ItemDisplay
- AllInOne including(assertion and functional flow)
							

### Listener (This function will automatically take a screenshot when error occured)
A TestNG Listener was implemented to capture screenshots automatically when any test fails.
##Screenshots are saved in (test-output/screenshots/)

##Dear Dr. Ashraf this is my Automation README and i included the important notes in this file i hope you find it good and thank you for your time. 

##And please note that i tried to cover all my knowledge and put it in this code, in some cases you will see ive used (WebElement) to locate and identify the element and in some cases i didnt use it just to make sure that i put everything in these tests, in general my point is i made sure to cover every subject.

							
							