package checkout;

import java.time.Duration;
import java.util.Random;

import listeners.TestListener;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.*;

import utils.HasDriver;

/* test flow 
 * login 
 * add items to the cart 
 * proceed to checkout and fill mandatory info 
 * and submit order 
 */


@Listeners({TestListener.class})
public class CheckoutSuccess implements HasDriver {

    private WebDriver driver;
    private final String website = "https://www.saucedemo.com/";

    @Override
    public WebDriver getDriver() {
        return driver;
    }

    public static void slowMo(WebDriver driver, long ms) {
        new Actions(driver).pause(Duration.ofMillis(ms)).perform();
    }

    @BeforeMethod
    public void setup() {
        driver = new EdgeDriver();
        driver.get(website);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
    }

    
    @Test
    public void checkoutSuccessTest() {

        
        Random rand       = new Random();
        int randomZipCode = rand.nextInt(10000, 99999);
        int randomFirst   = rand.nextInt(1000, 9000);
        int randomLast    = rand.nextInt(1000, 9000);

        // Login
        WebElement username = driver.findElement(By.id("user-name"));
        slowMo(driver, 1100);
        username.sendKeys("standard_user");

        WebElement password = driver.findElement(By.id("password"));
        slowMo(driver, 1100);
        password.sendKeys("secret_sauce");

        WebElement loginButton = driver.findElement(By.id("login-button"));
        slowMo(driver, 1100);
        loginButton.click();
        
        slowMo(driver, 1100);        
        driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();

        slowMo(driver, 1100);
        driver.findElement(By.id("add-to-cart-sauce-labs-onesie")).click();

        slowMo(driver, 1100);
        driver.findElement(By.id("add-to-cart-sauce-labs-bike-light")).click();

        
        WebElement cart = driver.findElement(By.cssSelector("[data-test='shopping-cart-link']"));
        slowMo(driver, 1100);
        cart.click();

        WebElement checkout = driver.findElement(By.id("checkout"));
        slowMo(driver, 1100);
        checkout.click();

        WebElement firstName = driver.findElement(By.id("first-name"));
        slowMo(driver, 1100);
        firstName.sendKeys("zaid" + randomFirst);

        WebElement lastName = driver.findElement(By.id("last-name"));
        slowMo(driver, 1100);
        lastName.sendKeys("shoto" + randomLast);

        WebElement zipCode = driver.findElement(By.id("postal-code"));
        slowMo(driver, 1100);
        zipCode.sendKeys(String.valueOf(randomZipCode));

        WebElement continueButton = driver.findElement(By.id("continue"));
        slowMo(driver, 1100);
        continueButton.click();

        WebElement finishButton = driver.findElement(By.id("finish"));
        slowMo(driver, 1100);
        finishButton.click();

        WebElement backHome = driver.findElement(By.id("back-to-products"));
        slowMo(driver, 1100);
        backHome.click();

        //force fail to confirm screenshot works, remove the comment to use it 
        // org.testng.Assert.fail("Force failure to test screenshot listener");
    }
}
