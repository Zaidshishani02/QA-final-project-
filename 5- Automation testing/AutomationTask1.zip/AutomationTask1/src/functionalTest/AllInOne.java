package functionalTest;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import listeners.TestListener;
import utils.HasDriver;

@Listeners({TestListener.class})
public class AllInOne implements HasDriver {

    /* Test Flow
     * Login then check title
     * test inventory page
     * check image clickAbility
     * check name and price
     * add to cart then check name and price in the cart
     */

    public static void slowMo(WebDriver driver, long ms) {
        new Actions(driver).pause(Duration.ofMillis(ms)).perform();
    }

    
    WebDriver driver = new EdgeDriver();

    
    @Override
    public WebDriver getDriver() {
        return driver;
    }

    String Website       = "https://www.saucedemo.com/";
    String ExpectedTitle = "Swag Labs";
    String ExpectedName  = "Sauce Labs Bike Light";
    String ExpectedPrice = "$9.99";

    @BeforeTest
    public void setup() {

        driver.get(Website);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
    }

    //1) Login and get title
    @Test(priority=1)
    public void getTitle() {

        WebElement Username    = driver.findElement(By.id("user-name"));
        slowMo(driver, 1100);
        Username.sendKeys("standard_user");

        WebElement Password    = driver.findElement(By.id("password"));
        slowMo(driver, 1100);
        Password.sendKeys("secret_sauce");

        WebElement LoginButton = driver.findElement(By.id("login-button"));
        slowMo(driver, 1100);
        LoginButton.click();

        //Title check after login
        String ActualTitle = driver.getTitle();

        System.out.println("ExpectedTitle: "+ExpectedTitle);
        System.out.println("ActualTitle:   "+ActualTitle);
        Assert.assertEquals(ActualTitle, ExpectedTitle, "Title does not match" );

    }

    // 2) Inventory page checks
    @Test(priority=2)
    public void Check_inventory() {

        boolean inventoryPageLoaded = driver.findElement(By.id("inventory_container")).isDisplayed();
        Assert.assertTrue(inventoryPageLoaded, "Inventory container should be visible.");
    }

    // 3) ClickAble Onesie image check
    @Test(priority=3)
    public void ClickAble_image() {

        WebElement ImageClick = driver.findElement(By.cssSelector("[data-test='inventory-item-sauce-labs-onesie-img']"));
        slowMo(driver, 4100);
        ImageClick.click();

        // Element checks on details page
        boolean productName  = driver.findElement(By.className("inventory_details_name")).isDisplayed();
        boolean productPrice = driver.findElement(By.className("inventory_details_price")).isDisplayed();
        boolean productImage = driver.findElement(By.className("inventory_details_img")).isDisplayed();

        Assert.assertTrue(productName,  "Product Name should be displayed.");
        Assert.assertTrue(productPrice, "Product Price should be displayed.");
        Assert.assertTrue(productImage, "Product Image should be displayed.");

        slowMo(driver, 4000);

        WebElement backtoproducts = driver.findElement(By.id("back-to-products"));
        backtoproducts.click();

    }

    // 4) Data checks (name and price)
    @Test(priority=4)
    public void Data_check(){

        WebElement BikeLight = driver.findElement(By.cssSelector("[data-test='inventory-item-sauce-labs-bike-light-img']"));
        slowMo(driver, 2000);
        BikeLight.click();

        WebElement name    = driver.findElement(By.className("inventory_details_name"));
        WebElement price   = driver.findElement(By.className("inventory_details_price"));

        String actualName  = name.getText().trim();
        String actualPrice = price.getText().trim();

        Assert.assertEquals(actualName,  ExpectedName,  "Product name should match expected.");
        Assert.assertEquals(actualPrice, ExpectedPrice, "Product price should match expected.");

        WebElement backtoproducts = driver.findElement(By.id("back-to-products"));
        slowMo(driver, 2500);
        backtoproducts.click();
    }

    // 9) Add to cart + cart badge
    @Test(priority=5)
    public void cart_bagde_cart_details() {

        String ExpectedNameforFleece  = "Sauce Labs Fleece Jacket";
        String ExpectedPriceforFleece = "$49.99";

        WebElement AddFleeceToCart = driver.findElement(By.id("add-to-cart-sauce-labs-fleece-jacket"));
        slowMo(driver, 1400);
        AddFleeceToCart.click();

        WebElement cartBadge = driver.findElement(By.className("shopping_cart_badge"));
        Assert.assertEquals(cartBadge.getText().trim(), "1", "Cart badge should show 1 item.");

        //Go to cart and verify same item name and price
        driver.findElement(By.cssSelector("[data-test='shopping-cart-link']")).click();

        WebElement cartItemName  = driver.findElement(By.className("inventory_item_name"));
        WebElement cartItemPrice = driver.findElement(By.className("inventory_item_price"));

        Assert.assertEquals(cartItemName.getText().trim(),  ExpectedNameforFleece,  "Cart item name should match expected.");
        Assert.assertEquals(cartItemPrice.getText().trim(), ExpectedPriceforFleece, "Cart item price should match expected.");
    }
}



    
    
    
	
	


