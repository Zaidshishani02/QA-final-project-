package listeners;

import utils.HasDriver;
import org.openqa.selenium.*;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import java.io.File;
import java.nio.file.*;

public class TestListener implements ITestListener {

    @Override
    public void onTestFailure(ITestResult result) {
        try {
            Object instance = result.getInstance();

            if (!(instance instanceof HasDriver)) {
                System.out.println("❌ Could not capture screenshot: Test class does not implement HasDriver");
                return;
            }

            WebDriver driver = ((HasDriver) instance).getDriver();
            takeScreenshot(driver, result.getName());

        } catch (Exception e) {
            System.out.println("❌ Could not capture screenshot: " + e.getMessage());
        }
    }

    private void takeScreenshot(WebDriver driver, String testName) throws Exception {
        if (driver == null) {
            System.out.println("❌ Could not capture screenshot: driver is null");
            return;
        }

        Path screenshotsDir = Paths.get("test-output", "screenshots");
        Files.createDirectories(screenshotsDir);

        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        Path dest = screenshotsDir.resolve(testName + "_" + System.currentTimeMillis() + ".png");

        Files.copy(src.toPath(), dest, StandardCopyOption.REPLACE_EXISTING);
        System.out.println("✅ Saved screenshot: " + dest.toAbsolutePath());
    }

    @Override public void onStart(ITestContext context) {}
    @Override public void onFinish(ITestContext context) {}
    @Override public void onTestStart(ITestResult result) {}
    @Override public void onTestSuccess(ITestResult result) {}
    @Override public void onTestSkipped(ITestResult result) {}
    @Override public void onTestFailedButWithinSuccessPercentage(ITestResult result) {}
}
