package utils;

import org.openqa.selenium.WebDriver;


public interface HasDriver {
	
	WebDriver getDriver();

}
