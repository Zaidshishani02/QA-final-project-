package login;

import java.time.Duration;

import listeners.TestListener;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.*;

import utils.HasDriver;

/* test flow 
 * login using valid info 
 */


@Listeners({TestListener.class})
public class LoginPage implements HasDriver {

    private WebDriver driver;
    private final String website = "https://www.saucedemo.com/";

    @Override
    public WebDriver getDriver() {
        return driver;
    }

    public static void slowMo(WebDriver driver, long ms) {
        new Actions(driver).pause(Duration.ofMillis(ms)).perform();
    }

    @BeforeMethod
    public void setup() {
        driver = new EdgeDriver();
        driver.get(website);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
    }


    @Test
    public void validLoginTest() {

        WebElement username = driver.findElement(By.id("user-name"));
        slowMo(driver, 1100);
        username.sendKeys("standard_user");

        WebElement password = driver.findElement(By.id("password"));
        slowMo(driver, 1100);
        password.sendKeys("secret_sauce");

        WebElement loginButton = driver.findElement(By.id("login-button"));
        slowMo(driver, 1100);
        loginButton.click();

        //force fail to confirm screenshot works, remove the comment to use it 
        // org.testng.Assert.fail("Force failure to test screenshot listener");
    }
}
