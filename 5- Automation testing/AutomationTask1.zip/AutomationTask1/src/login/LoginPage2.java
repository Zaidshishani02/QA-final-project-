package login;

import java.time.Duration;


import listeners.TestListener;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.*;

import utils.HasDriver;

/* test flow
 * login using invalid info 
 */


@Listeners({TestListener.class})
public class LoginPage2 implements HasDriver {

    private WebDriver driver;
    private final String website = "https://www.saucedemo.com/";

    @Override
    public WebDriver getDriver() {
        return driver;
    }

    public static void slowMo(WebDriver driver, long ms) {
        new Actions(driver).pause(Duration.ofMillis(ms)).perform();
    }

    @BeforeMethod
    public void setup() {
        driver = new EdgeDriver();
        driver.get(website);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
    }

   
    @Test
    public void invalidLoginTest() {

        WebElement username = driver.findElement(By.id("user-name"));
        slowMo(driver, 1100);
        username.sendKeys("standard_user");

        WebElement password = driver.findElement(By.id("password"));
        slowMo(driver, 1100);
        password.sendKeys("secret"); 

        WebElement loginButton = driver.findElement(By.id("login-button"));
        slowMo(driver, 1100);
        loginButton.click();

        
        WebElement error = driver.findElement(By.cssSelector("[data-test='error']"));
        String errorText = error.getText().trim();

        Assert.assertTrue(error.isDisplayed(),"Error message should be displayed for invalid login.");

        Assert.assertTrue(errorText.toLowerCase().contains("username and password do not match"),"Expected invalid login error message, but got: " + errorText);

        //force fail to confirm screenshot works, remove the comment to use it 
        // Assert.fail("Force failure to test screenshot listener");
    }
}
